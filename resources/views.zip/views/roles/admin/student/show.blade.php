<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="{{ asset('css/app.css') }}">

	<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
	<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
	<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
	<link rel="manifest" href="{{ asset('site.webmanifest') }}">

	<title>Sangnila Academy | LMS</title>

</head>

<body>
	<div class="bg-cover h-screen flex flex-col items-center"
		style="background-image: url({{ asset('img/background.png') }});">

		<x-navbar.admin></x-navbar.admin>
		<!-- Content Section -->
		<div class="container mx-auto mt-6 p-4 bg-white rounded-lg shadow-lg">
			<h1 class="text-3xl font-semibold text-blue-900 mb-4">Courses</h1>
			<div class="h-fit mb-5">
				<a class="px-5 py-2 bg-indigo-400 rounded-lg text-white hover:bg-gray-700 transition duration-300"
					href="{{ route('admin.student.assign.create', $student->id) }}">Assign Student to course</a>
			</div>
			@if ($student->enrolled_courses->isNotEmpty())
				<div class="overflow-x-auto rounded-md">
					<table class="min-w-full bg-white border-collapse">
						<thead>
							<tr>
								<td class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">Course Name</td>
								<th class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">Action</th>
							</tr>
						</thead>
						<tbody>
							@foreach ($student->enrolled_courses as $course)
								<tr>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4">
										<a href="{{ route('admin.course.show', ['course_id' => $course->id]) }}"
											class="text-blue-600 hover:text-blue-800 font-semibold hover:underline">
											{{ $course->course_name }}
										</a>
									</td>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4 text-center">
										<a
											href="{{ route('admin.student.unassign.delete', ['student_id' => $student->id, 'course_id' => $course->id]) }}"
											class="px-5 py-2 bg-indigo-400 rounded-lg text-white hover:bg-red-500 transition duration-300 block inline-block">
											Unassign
										</a>
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			@else
				<div class="text-blue-900">N/A</div>
			@endif

			{{-- Schedule --}}
			{{-- <h2 class="text-xl font-semibold mb-2">Student Schedules:</h2>

			@if ($student->schedules->isNotEmpty())
				<div class="overflow-x-auto">
					<table class="min-w-full bg-white border-collapse">
						<thead>
							<tr>
								<th class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">Course Name</th>
								<th class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">Day of Week</th>
								<th class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">Start Time</th>
								<th class="bg-blue-300 border-b border-blue-400 font-bold px-4 py-2 sm:w-1/4">End Time</th>
							</tr>
						</thead>
						<tbody>
							@forelse ($student->schedules as $schedule)
								<tr>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4">
										<a href="{{ route('admin.course.show', ['course_id' => $schedule->schedule->course->id ]) }}"
											class="text-blue-600 hover:text-blue-800 font-semibold hover:underline">
											{{ $schedule->schedule->course->course_name }}
										</a>
									</td>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4">
										{{ $schedule->schedule->day_of_week }}
									</td>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4">
										{{ $schedule->schedule->start_time }}
									</td>
									<td class="bg-blue-100 border-b border-blue-300 px-4 py-2 sm:w-1/4">
										{{ $schedule->schedule->end_time }}
									</td>
								</tr>
							@empty
								<tr>
									<td colspan="4" class="text-center py-2">No schedules found for this student.</td>
								</tr>
							@endforelse
						</tbody>
					</table>
				</div>
			@else
				<div class="text-blue-900">N/A</div>
			@endif --}}
		</div>
	</div>

</body>

</html>
